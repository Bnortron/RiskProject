Authors:

Tyler Leung - Dice Class, Attack Stage Methods

Braxton Martin - Initialization of Countries, Continents, Adjacent.

Braden Norton - Base Skeleton of Classes

Known Issues:

No Actual Turns

No Player Troop Initialization

No Working Combat

Doesn't Check Adjacent

Roadmap:

Add Turn System

Add Working Combat

Fix Adjacent Check

Add GUI
# RiskProject

# Changelog (11/09/20)
# Deliverables:

executable jar file (containing source code and javadoc)

UML Class Diagram of MVC

Design Decisions Text File

User Manual Text File

ReadMe Text File


# Authors:

Tyler Leung - Wrote Documentation, Helped on Country Setup, Wrote Troop Initialization and Country Assignment

Braxton Martin - Added Turn Base System, Worked on Country Setup

Braden Norton - Made GUI


# Future Roadmap:

Add bonus army placement

Add troupe movement

Save/Load Features

Custom Maps


# Known Issues:
